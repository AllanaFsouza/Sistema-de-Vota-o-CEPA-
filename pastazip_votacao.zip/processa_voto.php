<?php
session_start();
include 'conexao.php';

// Verifica se a matrícula está na sessão (o eleitor está logado)
if (!isset($_SESSION['matricula'])) {
    echo json_encode(["status" => "error", "message" => "Sessão expirada. Refaça a identificação."]);
    $conn->close();
    exit;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    $matricula = $_SESSION['matricula'];
    $voto = $_POST['voto_candidato']; // Recebe o id do candidato (A, B, C...)

    // 1. REGISTRAR O VOTO
    $stmt_voto = $conn->prepare("INSERT INTO Votos (matricula_eleitor, id_candidato_votado) VALUES (?, ?)");
    $stmt_voto->bind_param("ss", $matricula, $voto);
    
    if ($stmt_voto->execute()) {
        
        // 2. MARCAR O ELEITOR COMO JÁ VOTOU
        $stmt_update = $conn->prepare("UPDATE Eleitores SET ja_votou = 'S' WHERE matricula = ?");
        $stmt_update->bind_param("s", $matricula);
        $stmt_update->execute();
        $stmt_update->close();
        
        echo json_encode(["status" => "success", "message" => "Voto registrado com sucesso!"]);
        
    } else {
        echo json_encode(["status" => "error", "message" => "Erro ao registrar voto: " . $stmt_voto->error]);
    }
    
    $stmt_voto->close();
    $conn->close();
} else {
    echo json_encode(["status" => "error", "message" => "Método inválido."]);
}
?>