<?php
session_start();
include 'conexao.php';
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Status da Votação - CEPA</title>
    <style>

body { font-family: Arial, sans-serif; margin: 0; background-color: #f7f7f7; text-align: center; margin-left: 740px; }
.header { background-color: #008b6d; padding: 50px 20px; text-align: left; position: relative; z-index: 10; }
.logo-direita { position: absolute; top: 50%; right: 20px; transform: translateY(-50%); width: 200px; height: auto; z-index: 20; }
.faixa { background-color: #008b6d; height: 10px; position: relative; z-index: 10; }
.sidebar { background-color: #135e4d; width: 740px; height: 100vh; position: fixed; top: 0; left: 0; z-index: 1; overflow: hidden; }
.logo-sidebar { position: absolute; width: 100%; height: 100%; object-fit: cover; top: 0; left: 0; }
.container { background: white; padding: 40px; border-radius: 10px; box-shadow: 0 4px 12px rgba(0,0,0,0.1); max-width: 800px; margin: 50px auto; text-align: left; opacity: 0; }
table { width: 100%; border-collapse: collapse; margin-top: 20px; }
th, td { padding: 12px; border: 1px solid #ddd; text-align: left; }
th { background-color: #008b6d; color: white; }
tr:nth-child(even) { background-color: #f2f2f2; }
.total-row { font-weight: bold; background-color: #e0f2f1 !important; }
.btn-voltar { display: inline-block; margin-top: 20px; padding: 10px 20px; background-color: #008b6d; color: white; text-decoration: none; border-radius: 5px; font-weight: bold; transition: all 0.2s; }
.btn-voltar:hover { background-color: #005f4d; transform: scale(1.05); }
@keyframes fadeInLeft { from { opacity: 0; transform: translateX(50px); } to { opacity: 0.8; transform: translateX(0); } }
.fade-in-left { animation: fadeInLeft 1.2s ease-out forwards; }
@keyframes fadeInUp { from { opacity: 0; transform: translateY(40px); } to { opacity: 1; transform: translateY(0); } }
.fade-in-up { animation: fadeInUp 1s ease-out forwards; animation-delay: 0.1s; }

</style>
</head>
<body>
    <div class="sidebar">
        <img src="senaifundo.png" alt="Sidebar" class="logo-sidebar fade-in-left">
    </div>

    <div class="header">
        <img src="senailogo.png" alt="Logo SENAI" class="logo-direita">
    </div>

    <div class="faixa"></div>

    <div class="container fade-in-up">
        <h2>Resultados em Tempo Real</h2>
        <p>A tabela abaixo é atualizada automaticamente a cada 5 segundos.</p>
        
        <table>
            <thead>
                <tr>
                    <th>Candidato</th>
                    <th>Votos</th>
                    <th>Porcentagem</th>
                </tr>
            </thead>
            <tbody id="tabelaVotos">
                <tr><td colspan="3" style="text-align:center;">Carregando dados...</td></tr>
            </tbody>
            <tfoot id="rodapeTabela"></tfoot>
        </table>

        <a href="index.php" class="btn-voltar">← Voltar para Votação</a>
    </div>

    <script>
        // ... (seu código JavaScript de carregarStatusVotos permanece o mesmo)
        function carregarStatusVotos() {
            fetch('carrega_status.php')
            .then(response => response.json())
            .then(data => {
                if (data.status === 'success') {
                    const corpoTabela = document.getElementById('tabelaVotos');
                    const rodapeTabela = document.getElementById('rodapeTabela');
                    corpoTabela.innerHTML = '';
                    rodapeTabela.innerHTML = '';

                    const resultados = data.resultados;
                    const totalVotos = data.totalVotos;

                    if (totalVotos === 0) {
                        corpoTabela.innerHTML = '<tr><td colspan="3" style="text-align:center;">Nenhum voto registrado ainda.</td></tr>';
                        return;
                    }
                    
                    resultados.forEach(item => {
                        const porcentagem = ((item.count / totalVotos) * 100).toFixed(2);
                        const row = corpoTabela.insertRow();
                        row.innerHTML = `
                            <td>${item.id_candidato} - ${item.nome_candidato}</td>
                            <td>${item.count}</td>
                            <td>${porcentagem}%</td>
                        `;
                    });

                    const totalRow = rodapeTabela.insertRow();
                    totalRow.className = 'total-row';
                    totalRow.innerHTML = `
                        <td colspan="2" style="text-align: right; padding-right: 20px;">TOTAL GERAL</td>
                        <td>${totalVotos}</td>
                    `;
                }
            })
            .catch(error => {
                console.error('Erro:', error);
                document.getElementById('tabelaVotos').innerHTML = '<tr><td colspan="3" style="color: red; text-align:center;">Erro ao carregar dados.</td></tr>';
            });
        }

        carregarStatusVotos(); 
        setInterval(carregarStatusVotos, 5000); 
    </script>
</body>
</html>