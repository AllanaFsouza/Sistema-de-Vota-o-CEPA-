<?php
session_start(); 
include 'conexao.php'; 

// Verifica se os dados foram enviados via POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    $matricula = $_POST['matricula_eleitor'];
    $nome = $_POST['nome_eleitor'];
    $setor = $_POST['setor_eleitor'];

    // 1. VERIFICAR SE O ELEITOR JÁ VOTOU ou se precisa ser inserido
    $stmt = $conn->prepare("SELECT ja_votou FROM Eleitores WHERE matricula = ?");
    $stmt->bind_param("s", $matricula);
    $stmt->execute();
    $result = $stmt->get_result();
    
    // Eleitor encontrado no banco
    if ($result->num_rows > 0) {
        $eleitor = $result->fetch_assoc();
        
        if ($eleitor['ja_votou'] == 'S') {
            echo json_encode(["status" => "error", "message" => "Você já registrou seu voto."]);
            $stmt->close();
            $conn->close();
            exit;
        }
    } else {
        // 2. SE O ELEITOR NÃO EXISTE, INSERIR NA TABELA
        $stmt_insert = $conn->prepare("INSERT INTO Eleitores (matricula, nome_eleitor, setor_eleitor) VALUES (?, ?, ?)");
        $stmt_insert->bind_param("sss", $matricula, $nome, $setor);
        
        if (!$stmt_insert->execute()) {
            echo json_encode(["status" => "error", "message" => "Erro ao registrar eleitor: " . $stmt_insert->error]);
            $stmt_insert->close();
            $conn->close();
            exit;
        }
        $stmt_insert->close();
    }
    
    // Se passou na verificação/inserção:
    $_SESSION['matricula'] = $matricula;
    
    echo json_encode(["status" => "success", "message" => "Identificação validada. Prossiga para a votação."]);

    $stmt->close();
    $conn->close();
} else {
    echo json_encode(["status" => "error", "message" => "Método inválido."]);
}
?>