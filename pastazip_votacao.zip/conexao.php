<?php

$servername = "localhost"; // servidor
$username = "root";       // usuario
$password = "";           // senha 
$dbname = "votacaoo";      // nome do banco

// Cria a conexão
$conn = new mysqli($servername, $username, $password, $dbname);

// Verifica a conexão 
if ($conn->connect_error) { 
    die("Erro de conexão: " . $conn->connect_error); 
}


?>