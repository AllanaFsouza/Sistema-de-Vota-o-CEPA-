<?php
include 'conexao.php';
header('Content-Type: application/json');

$data = json_decode(file_get_contents('php://input'), true);

if ($data) {
    foreach ($data as $candidato) {
        $id = $conn->real_escape_string($candidato['id']);
        $nome = $conn->real_escape_string($candidato['nome']);
        $desc = $conn->real_escape_string($candidato['descricao']);
        
        // Nomes das colunas exatos conforme seu arquivo .sql
        $sql = "UPDATE Candidatos SET 
                nome_candidato = '$nome', 
                descricao_candidato = '$desc' 
                WHERE id_candidato = '$id'";
        $conn->query($sql);
    }
    echo json_encode(['status' => 'success']);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Dados não recebidos']);
}
?>