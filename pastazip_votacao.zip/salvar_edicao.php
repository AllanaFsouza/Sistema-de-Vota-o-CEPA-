<?php
// salvar_edicao.php
header('Content-Type: application/json');

// 1. Configurações do Banco - VERIFIQUE SE O NOME É 'votacaoo' MESMO
$host = "localhost";
$user = "root";
$pass = "";
$db   = "votacaoo"; 

$conn = new mysqli($host, $user, $pass, $db);

// Verifica se houve erro na conexão inicial
if ($conn->connect_error) {
    echo json_encode(['status' => 'error', 'message' => 'Erro de conexão com o MySQL: ' . $conn->connect_error]);
    exit;
}

// 2. Recebe os dados
$json = file_get_contents('php://input');
$dadosCandidatos = json_decode($json, true);

if (!$dadosCandidatos) {
    echo json_encode(['status' => 'error', 'message' => 'Dados inválidos ou vazios']);
    exit;
}

// 3. Processa a atualização
$sucesso = true;
$erroSql = "";

foreach ($dadosCandidatos as $candidato) {
    $id   = $conn->real_escape_string($candidato['id']);   // Vem como 'A', 'B', etc.
    $nome = $conn->real_escape_string($candidato['nome']);
    $desc = $conn->real_escape_string($candidato['descricao']);

    // IMPORTANTE: Onde está 'identificador', deve ser o nome da coluna no seu banco
    $sql = "UPDATE candidatos SET nome='$nome', descricao='$desc' WHERE identificador='$id'";
    
    if (!$conn->query($sql)) {
        $sucesso = false;
        $erroSql = $conn->error;
        break; 
    }
}

if ($sucesso) {
    echo json_encode(['status' => 'success', 'message' => 'Candidatos atualizados']);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Erro no SQL: ' . $erroSql]);
}

$conn->close();
?>