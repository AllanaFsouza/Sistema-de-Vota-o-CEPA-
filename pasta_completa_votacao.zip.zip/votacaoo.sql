CREATE TABLE IF NOT EXISTS Candidatos (
    id_candidato VARCHAR(10) PRIMARY KEY,
    nome_candidato VARCHAR(100) NOT NULL,
    descricao_candidato VARCHAR(255),
    url_foto VARCHAR(255)
);

CREATE TABLE IF NOT EXISTS Eleitores (
    matricula VARCHAR(50) PRIMARY KEY,
    nome_eleitor VARCHAR(100) NOT NULL,
    setor_eleitor VARCHAR(100),
    ja_votou CHAR(1) NOT NULL DEFAULT 'N'
);

CREATE TABLE IF NOT EXISTS Votos (
    id_voto INT PRIMARY KEY AUTO_INCREMENT,
    matricula_eleitor VARCHAR(50) NOT NULL,
    id_candidato_votado VARCHAR(10) NOT NULL,
    data_hora_voto DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (matricula_eleitor) REFERENCES Eleitores (matricula),
    FOREIGN KEY (id_candidato_votado) REFERENCES Candidatos (id_candidato)
);

INSERT INTO Candidatos (id_candidato, nome_candidato, descricao_candidato, url_foto) VALUES
('A', 'Candidato A', 'descrição', 'https://via.placeholder.com/100'),
('B', 'Candidato B', 'descrição', 'https://via.placeholder.com/100'),
('C', 'Candidato C', 'descrição', 'https://via.placeholder.com/100'),
('D', 'Candidato D', 'descrição', 'https://via.placeholder.com/100'),
('E', 'Candidato E', 'descrição', 'https://via.placeholder.com/100'),
('F', 'Candidato F', 'descrição', 'https://via.placeholder.com/100'),
('G', 'Candidato G', 'descrição', 'https://via.placeholder.com/100'),
('H', 'Candidato H', 'descrição', 'https://via.placeholder.com/100'),
('I', 'Candidato I', 'descrição', 'https://via.placeholder.com/100'),
('J', 'Candidato J', 'descrição', 'https://via.placeholder.com/100');