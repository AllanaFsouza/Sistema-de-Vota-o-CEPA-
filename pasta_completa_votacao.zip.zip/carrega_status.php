<?php
// Inclui a conexão com o banco de dados
include 'conexao.php'; 

// Define o cabeçalho para retornar dados em formato JSON
header('Content-Type: application/json');

try {
    // Consulta SQL para contar os votos por candidato.
    // LEFT JOIN garante que TODOS os candidatos apareçam, mesmo com 0 votos.
    $sql = "
        SELECT 
            C.id_candidato,
            C.nome_candidato,
            COUNT(V.id_voto) AS count
        FROM 
            Candidatos C
        LEFT JOIN 
            Votos V ON C.id_candidato = V.id_candidato_votado
        GROUP BY 
            C.id_candidato, C.nome_candidato
        ORDER BY 
            count DESC, C.id_candidato ASC;
    ";

    $result = $conn->query($sql);
    
    if ($result === false) {
        throw new Exception("Erro na consulta SQL: " . $conn->error);
    }
    
    $resultados = [];
    $totalVotos = 0;
    
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            // Converte a contagem de string para inteiro
            $row['count'] = (int)$row['count']; 
            $resultados[] = $row;
            $totalVotos += $row['count']; // Soma para obter o total geral
        }
    }
    
    // Retorna sucesso e os dados
    echo json_encode([
        "status" => "success",
        "resultados" => $resultados,
        "totalVotos" => $totalVotos
    ]);

} catch (Exception $e) {
    // Retorna erro se algo falhar
    echo json_encode([
        "status" => "error",
        "message" => $e->getMessage()
    ]);
} finally {
    // Fecha a conexão
    if (isset($conn)) {
        $conn->close();
    }
}
?>