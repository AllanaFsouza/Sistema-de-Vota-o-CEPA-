<?php
// 1. Conexão e busca de dados (Adicionado para tornar a página dinâmica)
include 'conexao.php';
$query = "SELECT * FROM Candidatos";
$result = $conn->query($query);
$candidatos_db = [];
if ($result) {
    while($row = $result->fetch_assoc()) {
        $candidatos_db[$row['id_candidato']] = $row;
    }
}
// Função para mostrar o nome do banco ou o padrão caso não exista no banco
function db($id, $campo, $default, $array) {
    return isset($array[$id][$campo]) ? $array[$id][$campo] : $default;
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistema de Votação CEPA</title>
<style>
/* MANTIDOS TODOS OS SEUS ESTILOS ORIGINAIS */
body { font-family: Arial, sans-serif; margin: 0; background-color: #f7f7f7; text-align: center; margin-left: 740px; }
.header { background-color: #008b6d; padding: 50px 20px; text-align: left; position: relative; z-index: 10; }
.faixa { background-color: #008b6d; height: 10px; position: relative; z-index: 10; }
.sidebar { background-color: #135e4d; width: 740px; height: 100vh; position: fixed; top: 0; left: 0; z-index: 1; }
.container { background: white; padding: 60px; border-radius: 10px; box-shadow: 0 4px 12px rgba(0,0,0,0.1); max-width: 600px; margin: 80px auto; text-align: left; }
.container:has(#votacao:not(.hidden)) { max-width: 900px; }
.container:has(#confirmacao:not(.hidden)) { max-width: 600px } 
h1 { color: #333; text-align: center; margin-bottom: 5px; font-size: 35px; }
.subtitulo { color: #333; text-align: center; margin-bottom: 20px; font-size: 18px; font-weight: bold; }
.instrucao { color: #555; text-align: center; margin-bottom: 30px; font-size: 14px; }
label { display: block; width: 100%; margin-bottom: 5px; font-size: 14px; font-weight: bold; }
input[type="text"], input[type="password"] { padding: 10px; border: 1px solid #ccc; border-radius: 5px; box-sizing: border-box; margin-bottom: 20px; width: 100%; }
button { background-color: #008080; color: white; padding: 10px; border: none; border-radius: 7px; cursor: pointer; font-size: 16px; margin-top: 10px; width: 100%; transition: transform 0.3s ease-in-out; display: block; }
button:hover { background-color: #005f5f; transform: scale(1.05); }
.btn-status { background-color: #5f9ea0; color: white; padding: 10px; border: none; border-radius: 7px; cursor: pointer; font-size: 16px; margin-top: 10px; width: 90%; display: block; text-align: center; text-decoration: none; transition: transform 0.3s ease-in-out; margin-left: 30px; margin-right: auto; }
.btn-status:hover { background-color: #4a8688; transform: scale(1.05); }
footer { background-color: #008b6d4f; color: white; text-align: center; padding: 7px 0; margin-top: 0; position: fixed; bottom: 0; left: 740px; width: calc(100% - 740px); z-index: 100; }
.area-candidatos { display: flex; flex-wrap: wrap; gap: 30px; justify-content: center; padding-top: 20px; }
.card-candidato { position: relative; background-color: #f0f0f0; border: 3px solid transparent; border-radius: 12px; padding: 20px; width: 180px; text-align: center; box-shadow: 0 4px 8px rgba(0,0,0,0.1); cursor: pointer; transition: all 0.3s ease-in-out; }
.card-candidato:hover { box-shadow: 0 6px 12px rgba(0,0,0,0.2); transform: translateY(-3px); }
.card-candidato img { width: 100px; height: 100px; border-radius: 50%; object-fit: cover; margin-bottom: 10px; }
.card-candidato h3 { color: #008b6d; margin: 5px 0 0; font-size: 18px; }
.card-candidato p { color: #555; font-size: 14px; }
.radio-candidato { display: none; }
.radio-candidato:checked + .card-candidato { background-color: #e0f2f1; border-color: #008080; box-shadow: 0 0 15px rgba(0,128,128,0.5); }
.btn-votar { margin-top: 40px; background-color: #008b6d; width: 70%; padding: 15px 30px; font-size: 18px; display: block; margin-left: auto; margin-right: auto; transition: transform 0.3s ease-in-out; }
.btn-votar:hover { background-color: #006b50; transform: scale(1.02); }
.btn-retorno { background-color: #5f9ea0; color: white; padding: 10px; border: none; border-radius: 7px; cursor: pointer; font-size: 16px; margin-top: 20px; width: 90%; display: block; text-align: center; text-decoration: none; transition: transform 0.3s ease-in-out; margin-left: 28px; margin-right: auto; }
.btn-retorno:hover { background-color: #4a8688; transform: scale(1.05); }
.seta { font-size: 1.2em; margin-right: 5px; font-weight: bold; }
.notificacao-custom { position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%); width: 350px; padding: 30px; background-color: white; border-radius: 10px; box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3); z-index: 200; text-align: center; border-top: 5px solid #008b6d; }
#notificacaoTexto { font-size: 16px; color: #333; margin-bottom: 20px; }
.btn-fechar { background-color: #008b6d; color: white; padding: 8px 20px; border: none; border-radius: 5px; cursor: pointer; font-size: 15px; transition: background-color 0.3s; width: 100px; margin: 0 auto; display: block; }
.btn-fechar:hover { background-color: #006b50; }
@keyframes fadeInUp { from { opacity: 0; transform: translate3d(0, 30px, 0); } to { opacity: 1; transform: translate3d(0, 0, 0); } }
.screen { animation-duration: 0.8s; animation-timing-function: ease-out; animation-fill-mode: both; opacity: 0; transform: translate3d(0, 30px, 0); }
.fade-in-up { animation-name: fadeInUp; opacity: 1; transform: translate3d(0, 0, 0); }
.hidden { display: none !important; }
.logo-direita { position: absolute; top: -50px; right: 20px; transform: translateY(-50%); width: 200px; height: auto; z-index: 20; animation-delay: 0.2s; }
.logo-sidebar { position: absolute; width: 100%; height: 100%; object-fit: cover; top: 0; left: 0; transform: none; opacity: 0.8; z-index: 5; }
#modalAdmin input { width: 80%; padding: 10px; border: 1px solid #ccc; border-radius: 5px; text-align: center; font-size: 16px; }
#modalAdmin { position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%); z-index: 1000; width: 350px; background-color: white; padding: 30px; border-radius: 10px; box-shadow: 0 10px 25px rgba(0,0,0,0.2); border-top: 5px solid #008b6d; text-align: center; }
.modal-overlay { position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0, 0, 0, 0.5); display: flex; justify-content: center; align-items: center; z-index: 20000; }
.modal-box { background: white; padding: 30px; border-radius: 15px; text-align: center; box-shadow: 0 10px 25px rgba(0,0,0,0.2); max-width: 400px; width: 90%; animation: entradaModal 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275) forwards; }
.modal-icon { font-size: 40px; margin-bottom: 15px; }
.modal-box p { font-size: 18px; color: #333; margin-bottom: 20px; font-weight: bold; }
.modal-box button { background-color: #008b6d; color: white; border: none; padding: 10px 30px; border-radius: 5px; cursor: pointer; font-weight: bold; transition: background 0.3s; }
.modal-box button:hover { background-color: #005f4d; }
@keyframes entradaModal { from { opacity: 0; transform: translateY(-50px) scale(0.9); } to { opacity: 1; transform: translateY(0) scale(1); } }
.save-button { position: absolute; top: 125px; right: 75px; width: auto; padding: 6px 12px; font-size: 12px; background-color: #28a745; color: white; border: none; border-radius: 4px; font-weight: bold; cursor: pointer; z-index: 1001; box-shadow: 0 2px 4px rgba(0,0,0,0.2); display: flex; align-items: center; transition: all 0.2s; }
.save-button:hover { background-color: #008b6d; transform: scale(1.05); }
.edit-mode { border: 2px dashed #008b6d; padding: 2px; background-color: #f0fdfa; outline: none; }
.config-icon { position: absolute; top: 125px; right: 25px; background: white; border: 2px solid #004a38; border-radius: 50%; width: 40px; height: 40px; font-size: 22px; cursor: pointer; z-index: 100; color: #004a38; display: flex; align-items: center; justify-content: center; box-shadow: 0 2px 5px rgba(0,0,0,0.2); }
.config-icon:hover { background-color: #f0f0f0; transform: rotate(90deg); }
@keyframes fadeInLeft { from { opacity: 0; transform: translate3d(30px, 0, 0); } to { opacity: 1; transform: translate3d(0, 0, 0); } }
.fade-in-left { animation-name: fadeInLeft; animation-duration: 0.8s; animation-timing-function: ease-out; animation-fill-mode: both; }
@keyframes notifyIn { from { opacity: 0; transform: translate(-50%, -45%) scale(0.95); } to { opacity: 1; transform: translate(-50%, -50%) scale(1); } }
@keyframes notifyOut { from { opacity: 1; transform: translate(-50%, -50%) scale(1); } to { opacity: 0; transform: translate(-50%, -55%) scale(0.95); } }
.animar-entrada { animation: notifyIn 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275) forwards; }
.animar-saida { animation: notifyOut 0.3s ease-in forwards; }
@keyframes modalFadeUp { from { opacity: 0; transform: translate(-50%, -40%); } to { opacity: 1; transform: translate(-50%, -50%); } }
.animar-modal { animation: modalFadeUp 0.5s ease-out forwards; }
.modal-box { background: white; padding: 30px; border-radius: 15px; text-align: center; box-shadow: 0 10px 25px rgba(0,0,0,0.2); max-width: 400px; width: 90%; }
@keyframes modalFadeUp { from { opacity: 0; transform: translateY(30px); } to { opacity: 1; transform: translateY(0); } }
.animar-modal { animation: modalFadeUp 0.5s ease-out forwards; }
#modalAdmin, #modalSenhaEdicao { position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%); z-index: 10000; width: 350px; background-color: white; padding: 30px; border-radius: 10px; box-shadow: 0 10px 25px rgba(0,0,0,0.3); border-top: 5px solid #008b6d; text-align: center; }
@keyframes modalFadeUp { from { opacity: 0; transform: translate(-50%, -40%); } to { opacity: 1; transform: translate(-50%, -50%); } }

</style>
</head>

<body>

<div class="sidebar"> 
    <img src="senaifundo.png" alt="Outra Logo" class="logo-sidebar screen fade-in-left"> 
</div>

<div class="header"> 
    <img src="senailogo.png" alt="Logo" class="logo-direita screen fade-in-up"> 
    <button class="config-icon hidden" id="btnConfig" onclick="solicitarSenhaAdmin()">⚙️</button>
    <button class="save-button hidden" id="idBtnSalvarReal" onclick="salvarAlteracoes()">SALVAR ALTERAÇÕES</button>
</div>

<div class="faixa"></div>

<div class="container"> 
    <div id="identificacao" class="screen fade-in-up"> 
        <h1>SISTEMA DE VOTAÇÃO CEPA</h1> 
        <p class="subtitulo">Por favor, identifique-se.</p> 
        <p class="instrucao">Informe sua matrícula e dados para liberar a votação.</p>
        <form id="formLogin">
            <label for="matricula_eleitor">Matrícula</label>
            <input type="text" id="matricula_eleitor" name="matricula_eleitor" placeholder="Matrícula" required>
            <label for="nome_eleitor">Nome</label>
            <input type="text" id="nome_eleitor" name="nome_eleitor" placeholder="Nome completo" required>
            <label for="setor_eleitor">Turma/Setor</label>
            <input type="text" id="setor_eleitor" name="setor_eleitor" placeholder="Turma ou setor" required>
            <button type="submit">Prosseguir para a Votação</button>
            <button type="button" class="btn-status" onclick="acessoAdmin()">Ver Status da Votação</button>
        </form>
    </div>

    <div id="votacao" class="screen hidden">
        <h1>Escolha seu Candidato</h1>
        <p class="subtitulo">Selecione o candidato de sua preferência (voto único).</p>
        <form id="formVotacaoCandidato">
            <div class="area-candidatos">
                <?php 
                
                $letras = range('A', 'J');
                foreach ($letras as $L): 
                ?>
                <input type="radio" id="candidato<?php echo $L; ?>" name="voto_candidato" value="<?php echo $L; ?>" class="radio-candidato" required> 
                <label for="candidato<?php echo $L; ?>" class="card-candidato"> 
                    <img src="https://via.placeholder.com/100" alt="Foto"> 
                    <h3 class="editavel"><?php echo db($L, 'nome_candidato', "Candidato $L", $candidatos_db); ?></h3> 
                    <p class="editavel"><?php echo db($L, 'descricao_candidato', "Nome", $candidatos_db); ?></p> 
                </label>
                <?php endforeach; ?>
            </div>
            <button type="submit" class="btn-votar">VOTAR AGORA</button>
        </form>
    </div>

    <div id="confirmacao" class="screen hidden">
        <h1>Voto Registrado!</h1>
        <p class="subtitulo">Seu voto foi contabilizado com sucesso.</p>
        <p class="instrucao">Obrigado por participar da Eleição CEPA.</p>
        <button type="button" id="btnNovoVoto" class="btn-retorno"><span class="seta">←</span> Voltar para o Início</button>
    </div>
</div>

<div id="notificacaoCustom" class="notificacao-custom hidden">
    <p id="notificacaoTexto"></p>
    <button id="fecharNotificacao" class="btn-fechar">OK</button>
</div>

<div id="modalAdmin" class="hidden">
    <h3>Acesso Restrito</h3>
    <p>Digite a senha de administrador:</p>
    <input type="password" id="senhaAdminInput" placeholder="Sua senha aqui">
    <div style="display: flex; gap: 10px; justify-content: center;">
        <button onclick="verificarSenhaAdmin()" class="btn-fechar">Entrar</button>
        <button onclick="fecharModalAdmin()" class="btn-fechar" style="background-color: #777;">Cancelar</button>
    </div>
</div>

<div id="modalSenhaEdicao" class="hidden">
    <h3>Modo de Edição</h3>
    <p>Digite a senha de administrador para editar os candidatos:</p>
    <input type="password" id="senhaEdicaoInput" placeholder="Senha de edição">
    <div style="display: flex; gap: 10px; justify-content: center;">
        <button onclick="confirmarSenhaEdicao()" class="btn-fechar">Ativar</button>
        <button onclick="fecharModalEdicao()" class="btn-fechar" style="background-color: #777;">Cancelar</button>
    </div>
</div>

<div id="modalContainer" class="modal-overlay hidden">
    <div class="modal-box">
        <div class="modal-icon">🔔</div>
        <p id="modalTexto">Mensagem aqui...</p>
        <button onclick="fecharModal()">OK</button>
    </div>
</div>

<footer> <p>&copy; SENAI BARÃO DE COCAIS - 2025</p> </footer>

<script>

const identificacaoDiv = document.getElementById('identificacao');
const votacaoDiv = document.getElementById('votacao');
const confirmacaoDiv = document.getElementById('confirmacao');
const formLogin = document.getElementById('formLogin');
const formVotacaoCandidato = document.getElementById('formVotacaoCandidato');
const notificacaoCustom = document.getElementById('notificacaoCustom');
const notificacaoTexto = document.getElementById('notificacaoTexto');
const fecharNotificacaoBtn = document.getElementById('fecharNotificacao');

function transicaoTelas(telaEsconder, telaMostrar) { // transção para a tela de candidatos 
    telaEsconder.classList.remove('fade-in-up');
    telaEsconder.classList.add('hidden');
    
    const btnConfig = document.getElementById('btnConfig');
    const btnSalvar = document.getElementById('idBtnSalvarReal');

    if (telaMostrar.id === 'votacao') {
        btnConfig.classList.remove('hidden');
    } else {
        btnConfig.classList.add('hidden');
        btnSalvar.classList.add('hidden'); 
    }

    setTimeout(() => {
        telaMostrar.classList.remove('hidden');
        void telaMostrar.offsetWidth;
        telaMostrar.classList.add('fade-in-up');
    }, 50); 
}

formLogin.addEventListener('submit', function(event) { // lógica para o login
    event.preventDefault();
    const formData = new FormData(formLogin);
    fetch('processa_login.php', { method: 'POST', body: formData })
    .then(response => response.json())
    .then(data => {
        if (data.status === 'success') {
            mostrarNotificacao("Sucesso: " + data.message);
            transicaoTelas(identificacaoDiv, votacaoDiv);
        } else { mostrarNotificacao("Erro: " + data.message); }
    })
    .catch(error => { mostrarNotificacao('Erro de conexão com o servidor.'); });
});

formVotacaoCandidato.addEventListener('submit', function(event) { // lógica para o voto
    event.preventDefault();
    const formData = new FormData(formVotacaoCandidato);
    fetch('processa_voto.php', { method: 'POST', body: formData })
    .then(response => response.json())
    .then(data => {
        if (data.status === 'success') { transicaoTelas(votacaoDiv, confirmacaoDiv); } 
        else { mostrarNotificacao("Erro ao votar: " + data.message); }
    })
    .catch(error => { mostrarNotificacao('Erro ao registrar o voto.'); });
});

document.getElementById('btnNovoVoto').addEventListener('click', function() { 
    formLogin.reset();
    formVotacaoCandidato.reset();
    transicaoTelas(confirmacaoDiv, identificacaoDiv);
});

function mostrarNotificacao(mensagem) { // notificação personalizada 
    notificacaoTexto.textContent = mensagem;
    notificacaoCustom.classList.remove('hidden', 'animar-saida');
    notificacaoCustom.classList.add('animar-entrada');
}

fecharNotificacaoBtn.addEventListener('click', function() {
    notificacaoCustom.classList.remove('animar-entrada');
    notificacaoCustom.classList.add('animar-saida');
    
    setTimeout(() => { 
        notificacaoCustom.classList.add('hidden'); 
    }, 300); 
});

function acessoAdmin() { // função para o adm conseguir acessar os status da votação 
    const modal = document.getElementById('modalAdmin');
    const input = document.getElementById('senhaAdminInput');
    
    input.value = ''; 
    modal.classList.remove('hidden');
    
    
    modal.classList.remove('animar-modal');
    void modal.offsetWidth; 
    modal.classList.add('animar-modal');
    
    input.focus(); // foca no campo da senha
}

function fecharModalAdmin() {
    const modal = document.getElementById('modalAdmin');
    modal.classList.add('hidden');
    modal.classList.remove('animar-modal');
}

function verificarSenhaAdmin() { // função para verificar a senha do adm 
    if (document.getElementById('senhaAdminInput').value === "admin123") { // senha do adm
        window.location.href = "status_votos.php";
    } else { 
        fecharModalAdmin(); 
        mostrarNotificacao("Senha incorreta!"); 
    }
}

function mostrarAviso(mensagem, tipo) { // mostra se as alterações foram atualizadas no bd 
    const modal = document.getElementById('modalContainer');
    const box = modal.querySelector('.modal-box'); 
    
    document.getElementById('modalTexto').innerText = mensagem;
    const icone = modal.querySelector('.modal-icon');
    
    icone.innerText = tipo === 'sucesso' ? "✅" : "⚠️";
    box.style.borderTop = tipo === 'sucesso' ? "5px solid #008b6d" : "5px solid #ff4b4b";
  
    modal.classList.remove('hidden');

    box.classList.remove('animar-modal');
    void box.offsetWidth; 
    box.classList.add('animar-modal');
}

function fecharModal() {
    const modal = document.getElementById('modalContainer');
    const box = modal.querySelector('.modal-box');
    const texto = document.getElementById('modalTexto').innerText;
    
    modal.classList.add('hidden');
    box.classList.remove('animar-modal'); 
    
    if (texto.includes("sucesso")) { 
        location.reload(); 
    }
}


function solicitarSenhaAdmin() { // modal que solicita a senha ao adm para realizar as modificações nos candidatos
    const modal = document.getElementById('modalSenhaEdicao');
    const input = document.getElementById('senhaEdicaoInput');
    
    input.value = ''; 
    modal.classList.remove('hidden');
    
    
    modal.classList.remove('animar-modal');
    void modal.offsetWidth; 
    modal.classList.add('animar-modal');
    
    input.focus();
}

function fecharModalEdicao() {
    document.getElementById('modalSenhaEdicao').classList.add('hidden');
}


function confirmarSenhaEdicao() { // valida a senha
    const senha = document.getElementById('senhaEdicaoInput').value;
    
    if (senha === "admin123") {
        fecharModalEdicao();
        mostrarAviso("Modo de edição ativado! Clique nos nomes para alterar.", "sucesso");
        ativarEdicao();
    } else {
        fecharModalEdicao();
        mostrarAviso("Senha incorreta!", "erro");
    }
}

function ativarEdicao() { // função que ativa a edição do adm
    const editaveis = document.querySelectorAll('.card-candidato h3, .card-candidato p');
    editaveis.forEach(el => {
        el.contentEditable = "true";
        el.classList.add('edit-mode');
        el.style.backgroundColor = "#fff8e1"; 
    });
    document.getElementById('idBtnSalvarReal').classList.remove('hidden');
}

function salvarAlteracoes() { // função que salva as alterações 
    const candidatos = [];
    document.querySelectorAll('.card-candidato').forEach((card) => {
        const idReal = card.previousElementSibling.value;
        candidatos.push({
            id: idReal, 
            nome: card.querySelector('h3').innerText,
            descricao: card.querySelector('p').innerText
        });
    });

    fetch('atualizar_candidatos.php', { 
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(candidatos)
    })
    .then(response => response.json())
    .then(data => {
        if (data.status === 'success') {
            mostrarAviso("Alterações salvas com sucesso no banco de dados!", "sucesso");
        } else {
            mostrarAviso("Erro ao salvar: " + data.message, "erro");
        }
    })
    .catch(error => {
        mostrarAviso("Erro de conexão com o servidor.", "erro");
    });
}
</script>
</body>
</html>